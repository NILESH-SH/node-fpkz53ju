# Accessible Todo — Angular 18

A beginner-friendly Todo application built with Angular 18 and designed to demonstrate practical web accessibility.

## Requirements

- Node.js 18.19+ or 20+
- npm

## Run

```bash
npm install
npm start
```

Open:

```text
http://localhost:4200
```

## Accessibility concepts demonstrated

### Semantic HTML
- `header`
- `main`
- `section`
- `footer`
- `form`
- `label`
- `ul` / `li`
- Native `button`
- Native `input`

### ARIA
- `aria-label`
- `aria-labelledby`
- `aria-describedby`
- `aria-live`
- `aria-atomic`
- `aria-invalid`
- `aria-pressed`
- `aria-controls`
- `aria-haspopup`
- `aria-modal`
- `role="alert"`
- `role="status"`
- `role="dialog"`
- `role="alertdialog"`
- `aria-hidden`

### Keyboard accessibility
- Skip link
- Native keyboard-operable controls
- Visible `:focus-visible` indicators
- Escape closes dialogs
- Enter submits the form
- Space activates native controls
- No clickable `div` is used as a button

### Focus management
- Focus moves to the task input after adding a task.
- Focus moves to the dialog heading when a dialog opens.
- Focus returns to the task input after closing a dialog.

### Forms
- Explicit labels
- Required-style validation behavior
- Error announcement
- `aria-invalid`
- `aria-describedby`
- Maximum length
- Clear error messages

### Dynamic content
Task additions, completions, deletions and filter changes are announced through an ARIA live region.

### Visual accessibility
- Strong focus indicator
- High-contrast text
- Responsive layout
- Reduced-motion support
- Forced-colors support
- Color is not the only way state is communicated
- Text alternatives for icon-only/decorative content

## Important note

There is no meaningful concept of "using every ARIA attribute." ARIA should only be used when native HTML cannot already provide the required semantics. This project intentionally prefers native HTML controls and adds ARIA where it provides useful additional information.

## Recommended testing

Test the app with:

1. Keyboard only
2. Chrome/Edge accessibility tree
3. NVDA on Windows
4. VoiceOver on macOS/iOS
5. axe DevTools or Lighthouse
6. Browser zoom at 200%
7. High-contrast / forced-colors mode
8. Reduced-motion preference

## Angular structure

```text
src/
├── app/
│   ├── app.component.ts
│   ├── app.component.html
│   └── app.component.css
├── index.html
├── main.ts
└── styles.css
```
