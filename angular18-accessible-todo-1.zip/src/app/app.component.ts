import { CommonModule } from '@angular/common';
import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

interface Todo {
  id: number;
  title: string;
  completed: boolean;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements AfterViewInit {
  @ViewChild('newTodoInput') newTodoInput!: ElementRef<HTMLInputElement>;
  @ViewChild('helpDialogTitle') helpDialogTitle!: ElementRef<HTMLElement>;
  @ViewChild('deleteDialogTitle') deleteDialogTitle!: ElementRef<HTMLElement>;
  @ViewChild('helpDialog') helpDialog!: ElementRef<HTMLElement>;
  @ViewChild('deleteDialog') deleteDialog!: ElementRef<HTMLElement>;

  todos: Todo[] = [
    { id: 1, title: 'Learn semantic HTML', completed: true },
    { id: 2, title: 'Practice Angular accessibility', completed: false }
  ];

  newTodo = '';
  filter: 'all' | 'active' | 'completed' = 'all';
  errorMessage = '';
  statusMessage = '';
  isHelpOpen = false;
  isDeleteDialogOpen = false;
  todoToDelete: Todo | null = null;

  ngAfterViewInit(): void {
    this.newTodoInput.nativeElement.focus();
  }

  get visibleTodos(): Todo[] {
    if (this.filter === 'active') {
      return this.todos.filter(todo => !todo.completed);
    }
    if (this.filter === 'completed') {
      return this.todos.filter(todo => todo.completed);
    }
    return this.todos;
  }

  get remainingCount(): number {
    return this.todos.filter(todo => !todo.completed).length;
  }

  addTodo(): void {
    const title = this.newTodo.trim();

    if (!title) {
      this.errorMessage = 'Please enter a task.';
      this.statusMessage = '';
      this.newTodoInput.nativeElement.focus();
      return;
    }

    if (title.length > 100) {
      this.errorMessage = 'Task must be 100 characters or fewer.';
      this.statusMessage = '';
      this.newTodoInput.nativeElement.focus();
      return;
    }

    this.todos = [
      ...this.todos,
      { id: Date.now(), title, completed: false }
    ];

    this.newTodo = '';
    this.errorMessage = '';
    this.statusMessage = `Task added: ${title}`;
    this.newTodoInput.nativeElement.focus();
  }

  toggleTodo(todo: Todo): void {
    todo.completed = !todo.completed;
    this.todos = [...this.todos];

    this.statusMessage = todo.completed
      ? `Task completed: ${todo.title}`
      : `Task marked active: ${todo.title}`;
  }

  requestDelete(todo: Todo): void {
    this.todoToDelete = todo;
    this.isDeleteDialogOpen = true;

    setTimeout(() => {
      this.deleteDialogTitle?.nativeElement.focus();
    });
  }

  confirmDelete(): void {
    if (!this.todoToDelete) return;

    const deletedTitle = this.todoToDelete.title;
    this.todos = this.todos.filter(todo => todo.id !== this.todoToDelete!.id);
    this.todoToDelete = null;
    this.isDeleteDialogOpen = false;
    this.statusMessage = `Task deleted: ${deletedTitle}`;
    this.newTodoInput.nativeElement.focus();
  }

  cancelDelete(): void {
    this.isDeleteDialogOpen = false;
    this.todoToDelete = null;
  }

  clearCompleted(): void {
    const count = this.todos.filter(todo => todo.completed).length;

    if (count === 0) {
      this.statusMessage = 'There are no completed tasks to clear.';
      return;
    }

    this.todos = this.todos.filter(todo => !todo.completed);
    this.statusMessage = `${count} completed task${count === 1 ? '' : 's'} cleared.`;
  }

  openHelp(): void {
    this.isHelpOpen = true;
    setTimeout(() => {
      this.helpDialogTitle?.nativeElement.focus();
    });
  }

  closeHelp(): void {
    this.isHelpOpen = false;
    this.newTodoInput.nativeElement.focus();
  }

  trackByTodo(_index: number, todo: Todo): number {
    return todo.id;
  }

  setFilter(filter: 'all' | 'active' | 'completed'): void {
    this.filter = filter;
    this.statusMessage = `Showing ${filter} tasks.`;
  }

  onDialogKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      event.preventDefault();
      if (this.isDeleteDialogOpen) {
        this.cancelDelete();
      } else {
        this.closeHelp();
      }
      return;
    }

    if (event.key !== 'Tab') return;

    const dialog = this.isDeleteDialogOpen
      ? this.deleteDialog?.nativeElement
      : this.helpDialog?.nativeElement;

    if (!dialog) return;

    const focusable = Array.from(
      dialog.querySelectorAll<HTMLElement>(
        'button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])'
      )
    );

    if (focusable.length === 0) {
      event.preventDefault();
      return;
    }

    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }
}