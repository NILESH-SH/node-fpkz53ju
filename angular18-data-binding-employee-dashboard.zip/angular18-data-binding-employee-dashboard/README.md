# Angular 18 Data Binding — Employee Dashboard

A beginner-friendly employee management project demonstrating Angular data binding with standalone components, strict TypeScript, accessible templates, template-driven forms, and browser `localStorage`.

## Requirements

- Node.js 18.19.1+ or 20.11.1+ (Node 20 LTS is recommended)
- npm
- A code editor such as Visual Studio Code

## Run the project

1. Extract this ZIP.
2. Open a terminal in the extracted `angular18-data-binding-employee-dashboard` folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Start the development server:

   ```bash
   npm start
   ```

5. Open the local URL printed in the terminal, usually `http://localhost:4200`.

To verify a production build, run `npm run build`.

## Features

- View, add, edit, select, and delete employee records.
- Search by employee name, email, or job title.
- Filter by department and employment status.
- Summary counts and average salary update from employee data.
- Browser `localStorage` persistence.
- Reset the demo data.
- Responsive layout, keyboard-visible focus, skip link, labelled fields, validation messages, and live status announcements.

## Data-binding map

| Concept | Where to look |
|---|---|
| Interpolation `{{ value }}` | `app.component.html`, `employee-card.component.html` |
| Property binding `[disabled]`, `[employee]` | All component templates |
| Attribute binding `[attr.aria-label]`, `[attr.aria-invalid]` | Employee card and form templates |
| Event binding `(click)`, `(ngSubmit)` | All component templates |
| Two-way binding `[(ngModel)]` | Search/filter inputs and employee form |
| Class binding `[class.selected]` | `employee-card.component.html` |
| Style binding `[style.opacity]` | `employee-card.component.html` changes inactive employee card opacity |
| Conditional rendering `@if / @else` | All component templates |
| List rendering `@for` | Directory, departments, statuses |
| Parent-to-child inputs | `app.component.html` passes `[employee]`, `[selected]`, `[employeeToEdit]` |
| Child-to-parent outputs | `(editRequested)`, `(deleteRequested)`, `(selectionRequested)`, `(saveEmployee)` |
| Template reference variables | `#employeeForm`, `#nameModel`, `#emailModel` |
| Pipes | `currency` and `number` in `app.component.html` and employee card |
| Template-driven validation | `employee-form.component.html` |
| Track rendered items | `@for (...; track employee.id)` |

## Important files

- `src/app/app.component.ts`: page state, filtering, statistics, and event handlers.
- `src/app/app.component.html`: dashboard template and most binding examples.
- `src/app/employee-card/`: reusable child component with inputs and outputs.
- `src/app/employee-form/`: form component with two-way binding and validation.
- `src/app/employee.service.ts`: CRUD operations and persistence.
- `src/app/employee.model.ts`: shared TypeScript types.

## Learning notes

### Interpolation
`{{ employee.name }}` evaluates a component expression and displays its value as text.

### Property binding
`[disabled]="employeeForm.invalid"` assigns a boolean to the button's DOM property. Use this for DOM properties such as `disabled`, `value`, and `checked`.

### Attribute binding
`[attr.aria-invalid]="isInvalid ? 'true' : null"` controls an HTML attribute. It is useful for ARIA attributes and attributes without matching DOM properties. Returning `null` removes the attribute.

### Class and style binding
`[class.selected]="selected"` adds or removes a CSS class based on a boolean. `[style.opacity]="employee.status === 'Inactive' ? 0.75 : 1"` sets a style value from an expression. Prefer CSS classes for complex styling; use style binding for small dynamic values.

### Event binding
`(click)="editEmployee(employee)"` calls the component method when the user clicks. `$event` is the emitted event value; for component outputs, it is the value emitted by the child.

### Two-way binding
`[(ngModel)]="searchText"` combines property and input/change event behavior so typing updates `searchText`, and changes to `searchText` are reflected in the input. `FormsModule` must be imported by the standalone component.

### Inputs and outputs
The parent passes data with `[employee]="employee"`. The child emits a value with `editRequested.emit(this.employee)`, and the parent receives it using `(editRequested)="editEmployee($event)"`.

## Manual test checklist

- Search for `Aarav`; only matching employees should remain.
- Filter to `Engineering`, then clear filters.
- Add a valid employee and confirm the summary changes.
- Submit the form with missing required values; submission should be disabled and validation should appear after touching fields.
- Edit an employee and save a change.
- Delete an employee and confirm the browser asks before deleting.
- Refresh the page; changes should persist in this browser.
- Use Tab and Shift+Tab to navigate and check that focus is visible.
- Resize the browser to mobile width and verify the layout stacks.
- Reset demo data to restore the five sample employees.

## Scope and production note

This is a learning project, not a production HR system. Browser storage is local to one browser/device and is not secure shared storage. A real application would normally use an authenticated backend API, authorization, server-side validation, audit logging, and automated tests.
