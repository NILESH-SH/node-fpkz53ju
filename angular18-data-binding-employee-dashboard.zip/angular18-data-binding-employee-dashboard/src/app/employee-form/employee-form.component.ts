import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Employee, EmployeeFormValue, EmploymentStatus } from '../employee.model';

@Component({
  selector: 'app-employee-form',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './employee-form.component.html',
  styleUrl: './employee-form.component.css'
})
export class EmployeeFormComponent implements OnChanges {
  @Input() employeeToEdit: Employee | null = null;
  @Output() saveEmployee = new EventEmitter<EmployeeFormValue>();
  @Output() cancelForm = new EventEmitter<void>();

  readonly departments = ['Engineering', 'Design', 'Human Resources', 'Finance', 'Marketing'];
  readonly statuses: EmploymentStatus[] = ['Active', 'On leave', 'Inactive'];

  formValue: EmployeeFormValue = this.emptyForm();
  isSubmitting = false;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['employeeToEdit']) {
      this.formValue = this.employeeToEdit
        ? this.toFormValue(this.employeeToEdit)
        : this.emptyForm();
      this.isSubmitting = false;
    }
  }

  submit(form: NgForm): void {
    if (form.invalid || this.isSubmitting) {
      form.control.markAllAsTouched();
      return;
    }
    this.isSubmitting = true;
    this.saveEmployee.emit({ ...this.formValue, salary: Number(this.formValue.salary) });
    this.isSubmitting = false;
    form.resetForm(this.emptyForm());
  }

  cancel(): void {
    this.cancelForm.emit();
  }

  private emptyForm(): EmployeeFormValue {
    return {
      name: '',
      email: '',
      department: 'Engineering',
      jobTitle: '',
      salary: 500000,
      status: 'Active'
    };
  }

  private toFormValue(employee: Employee): EmployeeFormValue {
    return {
      name: employee.name,
      email: employee.email,
      department: employee.department,
      jobTitle: employee.jobTitle,
      salary: employee.salary,
      status: employee.status
    };
  }
}
