export type EmploymentStatus = 'Active' | 'On leave' | 'Inactive';

export interface Employee {
  id: number;
  name: string;
  email: string;
  department: string;
  jobTitle: string;
  salary: number;
  status: EmploymentStatus;
}

export type EmployeeFormValue = Omit<Employee, 'id'>;
