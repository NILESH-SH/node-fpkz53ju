import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CurrencyPipe, TitleCasePipe } from '@angular/common';
import { Employee } from '../employee.model';

@Component({
  selector: 'app-employee-card',
  standalone: true,
  imports: [CurrencyPipe, TitleCasePipe],
  templateUrl: './employee-card.component.html',
  styleUrl: './employee-card.component.css'
})
export class EmployeeCardComponent {
  @Input({ required: true }) employee!: Employee;
  @Input() selected = false;

  @Output() editRequested = new EventEmitter<Employee>();
  @Output() deleteRequested = new EventEmitter<number>();
  @Output() selectionRequested = new EventEmitter<number>();

  requestEdit(): void {
    this.editRequested.emit(this.employee);
  }

  requestDelete(): void {
    this.deleteRequested.emit(this.employee.id);
  }

  requestSelection(): void {
    this.selectionRequested.emit(this.employee.id);
  }
}
