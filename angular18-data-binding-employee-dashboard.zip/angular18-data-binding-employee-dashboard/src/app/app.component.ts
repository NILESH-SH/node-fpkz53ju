import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CurrencyPipe, DecimalPipe } from '@angular/common';
import { EmployeeCardComponent } from './employee-card/employee-card.component';
import { EmployeeFormComponent } from './employee-form/employee-form.component';
import { Employee, EmployeeFormValue } from './employee.model';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, CurrencyPipe, DecimalPipe, EmployeeCardComponent, EmployeeFormComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  employees: Employee[] = [];
  searchText = '';
  selectedDepartment = 'All departments';
  selectedStatus = 'All statuses';
  selectedEmployeeId: number | null = null;
  employeeToEdit: Employee | null = null;
  statusMessage = '';
  showForm = true;

  readonly departmentOptions = ['All departments', 'Engineering', 'Design', 'Human Resources', 'Finance', 'Marketing'];
  readonly statusOptions = ['All statuses', 'Active', 'On leave', 'Inactive'];

  constructor(private readonly employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.refreshEmployees();
  }

  get filteredEmployees(): Employee[] {
    const search = this.searchText.trim().toLowerCase();
    return this.employees.filter((employee) => {
      const matchesSearch = !search ||
        employee.name.toLowerCase().includes(search) ||
        employee.email.toLowerCase().includes(search) ||
        employee.jobTitle.toLowerCase().includes(search);
      const matchesDepartment = this.selectedDepartment === 'All departments' ||
        employee.department === this.selectedDepartment;
      const matchesStatus = this.selectedStatus === 'All statuses' ||
        employee.status === this.selectedStatus;
      return matchesSearch && matchesDepartment && matchesStatus;
    });
  }

  get activeCount(): number {
    return this.employees.filter((employee) => employee.status === 'Active').length;
  }

  get departmentCount(): number {
    return new Set(this.employees.map((employee) => employee.department)).size;
  }

  get averageSalary(): number {
    if (this.employees.length === 0) return 0;
    const total = this.employees.reduce((sum, employee) => sum + employee.salary, 0);
    return total / this.employees.length;
  }

  saveEmployee(value: EmployeeFormValue): void {
    if (this.employeeToEdit) {
      const updated = this.employeeService.update(this.employeeToEdit.id, value);
      this.statusMessage = updated ? `${updated.name} was updated.` : 'Employee could not be found.';
    } else {
      const added = this.employeeService.add(value);
      this.statusMessage = `${added.name} was added.`;
    }
    this.employeeToEdit = null;
    this.refreshEmployees();
  }

  editEmployee(employee: Employee): void {
    this.employeeToEdit = { ...employee };
    this.showForm = true;
    this.statusMessage = `Editing ${employee.name}.`;
  }

  deleteEmployee(id: number): void {
    const employee = this.employees.find((item) => item.id === id);
    if (!employee) return;
    const confirmed = window.confirm(`Delete ${employee.name}? This cannot be undone.`);
    if (!confirmed) return;
    this.employeeService.delete(id);
    if (this.selectedEmployeeId === id) this.selectedEmployeeId = null;
    if (this.employeeToEdit?.id === id) this.employeeToEdit = null;
    this.refreshEmployees();
    this.statusMessage = `${employee.name} was deleted.`;
  }

  selectEmployee(id: number): void {
    this.selectedEmployeeId = this.selectedEmployeeId === id ? null : id;
    const employee = this.employees.find((item) => item.id === id);
    this.statusMessage = this.selectedEmployeeId === null
      ? 'Employee selection cleared.'
      : `${employee?.name ?? 'Employee'} selected.`;
  }

  cancelEditing(): void {
    this.employeeToEdit = null;
    this.statusMessage = 'Editing cancelled.';
  }

  clearFilters(): void {
    this.searchText = '';
    this.selectedDepartment = 'All departments';
    this.selectedStatus = 'All statuses';
    this.statusMessage = 'Search and filters cleared.';
  }

  resetDemoData(): void {
    const confirmed = window.confirm('Restore the original demo employees? Your current employee list will be replaced.');
    if (!confirmed) return;
    this.employeeService.resetDemoData();
    this.selectedEmployeeId = null;
    this.employeeToEdit = null;
    this.clearFilters();
    this.refreshEmployees();
    this.statusMessage = 'Demo employees restored.';
  }

  toggleForm(): void {
    this.showForm = !this.showForm;
    if (!this.showForm) this.employeeToEdit = null;
    this.statusMessage = this.showForm ? 'Employee form opened.' : 'Employee form hidden.';
  }

  trackByEmployeeId(_index: number, employee: Employee): number {
    return employee.id;
  }

  private refreshEmployees(): void {
    this.employees = this.employeeService.getAll();
  }
}
