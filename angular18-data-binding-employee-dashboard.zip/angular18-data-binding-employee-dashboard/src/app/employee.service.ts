import { Injectable } from '@angular/core';
import { Employee, EmployeeFormValue } from './employee.model';

const STORAGE_KEY = 'angular18-employee-dashboard';

const STARTER_EMPLOYEES: Employee[] = [
  { id: 1, name: 'Aarav Mehta', email: 'aarav@example.com', department: 'Engineering', jobTitle: 'Frontend Developer', salary: 850000, status: 'Active' },
  { id: 2, name: 'Diya Kapoor', email: 'diya@example.com', department: 'Design', jobTitle: 'Product Designer', salary: 780000, status: 'Active' },
  { id: 3, name: 'Kabir Singh', email: 'kabir@example.com', department: 'Human Resources', jobTitle: 'HR Specialist', salary: 650000, status: 'On leave' },
  { id: 4, name: 'Ananya Rao', email: 'ananya@example.com', department: 'Engineering', jobTitle: 'Backend Developer', salary: 920000, status: 'Active' },
  { id: 5, name: 'Ishaan Verma', email: 'ishaan@example.com', department: 'Finance', jobTitle: 'Financial Analyst', salary: 720000, status: 'Inactive' }
];

@Injectable({ providedIn: 'root' })
export class EmployeeService {
  private employees: Employee[] = this.loadEmployees();

  getAll(): Employee[] {
    return this.employees.map((employee) => ({ ...employee }));
  }

  add(value: EmployeeFormValue): Employee {
    const employee: Employee = { ...value, id: this.nextId() };
    this.employees = [...this.employees, employee];
    this.save();
    return { ...employee };
  }

  update(id: number, value: EmployeeFormValue): Employee | undefined {
    let updated: Employee | undefined;
    this.employees = this.employees.map((employee) => {
      if (employee.id !== id) return employee;
      updated = { ...value, id };
      return updated;
    });
    this.save();
    return updated ? { ...updated } : undefined;
  }

  delete(id: number): void {
    this.employees = this.employees.filter((employee) => employee.id !== id);
    this.save();
  }

  resetDemoData(): void {
    this.employees = STARTER_EMPLOYEES.map((employee) => ({ ...employee }));
    this.save();
  }

  private nextId(): number {
    return this.employees.reduce((highest, employee) => Math.max(highest, employee.id), 0) + 1;
  }

  private loadEmployees(): Employee[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed: unknown = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed as Employee[];
      }
    } catch {
      // If storage is unavailable or malformed, fall back to demo data.
    }
    return STARTER_EMPLOYEES.map((employee) => ({ ...employee }));
  }

  private save(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.employees));
    } catch {
      // The app remains usable for this session if browser storage is blocked.
    }
  }
}
